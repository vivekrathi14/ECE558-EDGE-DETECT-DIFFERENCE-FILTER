here
xxyy-
xx - image type
yy - filter
bl - greyscale lena
lc - colored lena
w- greyscale wolves
